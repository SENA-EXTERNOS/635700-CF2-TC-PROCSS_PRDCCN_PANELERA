function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5e0TIOndZD3":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

