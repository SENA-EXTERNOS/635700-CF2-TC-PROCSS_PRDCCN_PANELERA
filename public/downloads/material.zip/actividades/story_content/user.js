function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5z0E9jQcpA4":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

